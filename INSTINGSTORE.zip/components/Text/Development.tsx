
'use client'
import React from 'react';
import './styles.css';
import { Alert } from "flowbite-react";

function Development() {
  return (
    <div>
      <div>Navbar</div>
    <Alert className='text-container mt-14 bg-color-secondary'>
      <div className="marquee font-bold">
        <span className='text-white'>Website Ini Masih Dalam Prosess Pengembangan Mohon Untuk Kerjasama Nya Jika Anda Menemukan Bug Atau Error Silahkan Hubungi Admin @FahrurRozi Atau Admin Lainnya! Selamat Berbelanja! 👌👍</span>
      </div>
    </Alert>

    </div>
  );
}

export default Development;
