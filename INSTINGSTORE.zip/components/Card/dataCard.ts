
export const GameCards = [

    {
        imgAlt : "",
        href : "/games/CODM",
        imgSrc : "https://cdn.unipin.com/images/icon_product_pages/1633599388-icon-Icon_1024.jpg",
        onclick : "Call Of Duty M"
    },
    {
        imgAlt : "",
        href : "/games/undawn",
        imgSrc : "https://cdn.unipin.com/images/icon_product_pages/1689159121-icon-garena-undawn.jpg",
        onclick: "Undawn"
    },
    {
        imgAlt : "",
        href : "/games/ragnarok-origin",
        imgSrc : "https://cdn.unipin.com/images/icon_product_pages/1680764749-icon-%E5%9B%BE%E7%89%87_20230406150453.jpg",
        onclick : "Ragnarok Origin"
    },
    {
        imgAlt : "FreeFire",
        href : "/games/freefire",
        imgSrc : "https://cdn.unipin.com/images/icon_product_pages/1658817763-icon-200x200_icon%20ff.jpg",
        onclick : "Free Fire"
    },
    {
        imgAlt : "",
        href : "/games/clashofclans",
        imgSrc : "https://cdn1.codashop.com/S/content/mobile/images/product-tiles/ID_Clash-of-Clans-20%20(1).jpg",
        onclick : " Clash Of Clans"
    },
    {
        imgAlt: "Mobile Legends",
        href: "/games/mobile-legends",
        imgSrc: "https://cdn1.codashop.com/S/content/mobile/images/product-tiles/ID_MLBB-M4-Codacash-tile.jpg",
        onclick : 'Mobile Legends'
    },
    {
        imgAlt : "",
        href : "/games/toweroffantasy",
        imgSrc : "https://cdn.unipin.com/images/icon_product_pages/1663645620-icon-1662619195-icon-1662082730-icon-Tower%20of%20Fantasy%20logo%20-%201%20jpg.jpg",
        onclick : "Tower Of Fantasy"
    },
    {
        imgAlt : "",
        href : "/games/metalslug-awakening",
        imgSrc : "https://cdn.unipin.com/images/icon_product_pages/1691644925-icon-App%20Icon%20200x200_11zon.jpg",
        onclick : "Metal Slug -Awakening"
    },


    // Tambahkan objek-objek lain sesuai dengan kartu permainan Anda
  ];

  export const a = [

  ]