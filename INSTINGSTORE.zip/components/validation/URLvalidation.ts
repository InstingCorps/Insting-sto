
export const URLvalidation = (validation : any) => {
    const validate = "25012006RoziStore_FahrurRozi_001"
    if (validation === validate) {
        return true
    } else {
        return false
    }
}
export const ORDERvalidation = (validation : any) => {
    const validate = "25012006RoziStore_FahrurRozi_001_ORDERDISETUJUI"
    if (validation === validate) {
        return true
    } else {
        return false
    }
}
export const Validate = "25012006RoziStore_FahrurRozi_001"

