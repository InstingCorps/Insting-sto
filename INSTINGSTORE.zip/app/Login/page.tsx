import React from 'react'

const LoginPage = () => {
  return (
    <div>
      logins
    </div>
  )
}

export default LoginPage
