import TermsConditions from "@/components/modal/Terms & Conditions"

const page = () => {
  return (
    <div>
      <TermsConditions />
    </div>
  )
}

export default page
