import PrivacyPolicy from '@/components/modal/privacyPolicy'

const PagePricacyPolicy = () => {
  return (
    <div>
      <PrivacyPolicy />
    </div>
  )
}

export default PagePricacyPolicy
